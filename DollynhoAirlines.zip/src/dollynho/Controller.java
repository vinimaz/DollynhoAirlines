package dollynho;

import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.layout.Pane;

import java.net.URL;
import java.util.ResourceBundle;


public class Controller implements Initializable {

    public Button startBt;
    public Pane introPane;
    public Pane serverPane;
    public Pane painelCadastroPassagem;
    public TabPane tabPaneGeral;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void clicou(){
        introPane.setVisible(false);
        serverPane.setVisible(true);
    }

    public void abrirPaneCadastroPassagem(){
        tabPaneGeral.setVisible(false);
        painelCadastroPassagem.setVisible(true);
    }

    public void cancelarCadastroPassagens(){
        tabPaneGeral.setVisible(true);
        painelCadastroPassagem.setVisible(false);
    }


}
