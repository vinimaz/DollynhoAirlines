package dollynho;


import java.time.LocalDate;

/**
 * Created by vinimaz on 5/6/16.
 */
public class DispHospedagem {
    LocalDate dataInicio;
    boolean disponivel;
}
