package dollynho;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.time.LocalDate;

public class Servidor extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("interface.fxml"));
        primaryStage.setTitle("Dollynho Airlines Server");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }


    public static void main(String[] args) throws RemoteException, AlreadyBoundException {
        LocalDate datain    = LocalDate.of(2016, 01, 01);
        LocalDate dataout   = LocalDate.of(2016, 01, 10);
        Hospedagem hosp = new Hospedagem(1, 1, datain, dataout, 1);

        ServImpl server = new ServImpl();
        int port = 6789;
        Registry referenciaServicoNomes = LocateRegistry.createRegistry(port);
        referenciaServicoNomes.bind("Dollynho", server);
        System.out.println("Iniciado server RMI");
        launch(args);
    }
}
