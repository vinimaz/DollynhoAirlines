package dollynho;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

/**
 * Created by vinimaz on 5/5/16.
 */
public class Hospedagem {
    public int    quartos, hotel, cidade;
    LocalDate   dataInicio;
    ArrayList<Boolean> datasDisponiveis;

    public Hospedagem(int cidade, int hotel, LocalDate dataInicio, LocalDate dataFim, int quartos){
        datasDisponiveis    = new ArrayList<Boolean>();

        int periodo     = Period.between(dataInicio, dataFim).getDays();
        this.dataInicio = dataInicio;
        this.cidade     = cidade;
        this.hotel      = hotel;
        this.quartos    = quartos;

        for(int i = 0; i <= periodo; i++)
            datasDisponiveis.add(true);

        System.out.println("Criada hospedagem HOTEL " + hotel + " CIDADE " + cidade);
        System.out.println("Iniciando em " + dataInicio.getDayOfMonth() +"/"
                + dataInicio.getMonth() + "/" + dataInicio.getYear());
        System.out.println("Periodo de " + periodo + " dias");
    }
}
