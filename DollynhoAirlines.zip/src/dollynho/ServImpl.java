package dollynho;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by vinimaz on 5/5/16.
 */
public class ServImpl implements InterfaceServ {
    @Override
    public ArrayList<Passagem> getPassagens() {
        return null;
    }

    @Override
    public ArrayList<Passagem> getTodasPassagens() {
        return null;
    }

    @Override
    public ArrayList<Hospedagem> getTodasHospedagens() {
        return null;
    }

    @Override
    public ArrayList<Passagem> getSearchPassagens(int origem, int destino, Date ida, Date volta, int numAdultos, int numCriancas) {
        return null;
    }

    @Override
    public ArrayList<Hospedagem> getSearchHospedagem(int cidade, int hotel, Date inicio, Date fim, int qtdQuartos, int numPessoas) {
        return null;
    }

    @Override
    public void cadastraNotificacaoHospedagem(int cidade, int hotel, Date inicio, Date fim, int numPessoas, float preco) {

    }

    @Override
    public void cadastraNotificacaoPassagem(int origem, int destino, Date ida, Date volta, int numPessoas, float preco) {

    }
}
