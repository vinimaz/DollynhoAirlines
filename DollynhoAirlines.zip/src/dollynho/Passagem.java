package dollynho;

import java.time.LocalDate;
import java.util.Date;

/**
 * Created by vinimaz on 5/5/16.
 */
public class Passagem {
    LocalDate dataIda;
    float preco;
    int origem, destino, qtd;

    public Passagem(int origem, int destino, LocalDate dataIda, float preco, int qtd){
        this.dataIda        = dataIda;
        this.preco          = preco;
        this.qtd            = qtd;
        this.destino        = destino;
        System.out.println("Passagem criada:");
        System.out.println(origem + " -> " + destino + " $" + preco);
        System.out.println("QTD: " + qtd +  " " + dataIda.getDayOfMonth() + "/" +
                dataIda.getMonth() + "/" + dataIda.getYear());
    }
}
